Esp32 json link for Arduino.

https://dl.espressif.com/dl/package_esp32_index.json

Follow the instructions:

#open Arduino
#click file -> preferences-> Additional Boards Manager url.
#paste the above link there. 
#Apply and close "preferences"
#Click tools -> Boards Manager -> Let it get updated.
#Search ESP32 
#install the latest version esp32
#once done, click on tools again -> Boards(dont go for Boards Manager)-> scroll down to find esp32 dev module and select the board.

================================================================================================================

https://bit.ly/2m17es8
